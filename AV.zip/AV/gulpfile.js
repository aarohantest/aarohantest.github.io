var gulp = require('gulp'),
    gutil = require('gulp-util'),
    browserify = require('gulp-browserify'),
    connect = require('gulp-connect'),
    gulpif = require('gulp-if'),
    uglify = require('gulp-uglify'),
    cleanCSS = require('gulp-clean-css');
    htmlmin = require('gulp-htmlmin'),
    concat = require('gulp-concat');
    imagemin = require('gulp-imagemin');
    autoprefixer = require('gulp-autoprefixer');
    path = require('path');

var env,
    jsSources,
    sassSources,
    htmlSources,
    outputDir,
    sassStyle;

env = 'development';

if (env==='development') {
  outputDir = 'builds/development/';
  sassStyle = 'expanded';
} else {
  outputDir = 'builds/production/';
  sassStyle = 'compressed';
}

jsSources = [
  'components/js/jquery-2.1.3.min.js',
  'components/js/restive.js',
  'components/js/jquery.superslides.js',
  'components/js/script.js',
];
cssSources = [
  'components/styles/reset.css',
  'components/styles/superslides.css',
  'components/styles/index.css',
  'components/styles/about-us.css',
  'components/styles/disclaimer.css',
  'components/styles/termsofuse.css',
  'components/styles/privacypolicy.css',
  'components/styles/careers.css',
  'components/styles/responsive.css',
];
htmlSources = [outputDir + '*.html'];

gulp.task('connect', function() {
  connect.server({
    root: outputDir,
    port: 8080,
    livereload: true
  });
});

gulp.task('js', function() {
  gulp.src(jsSources)
   // .pipe(concat('script.js'))
  //  .pipe(browserify())
    .on('error', gutil.log)
    .pipe(gulp.dest(outputDir + 'js'))
    .pipe(connect.reload())
});

gulp.task('css', function() {
  gulp.src(cssSources)
    .pipe(concat('main.css'))
    .pipe(autoprefixer({
        browsers: ['> 1%', 'IE 8'],
        cascade: false,
        remove: false
    }))
    .on('error', gutil.log)
    .pipe(gulpif(env == 'production', cleanCSS({compatibility: 'ie8'})))
    .pipe(gulp.dest(outputDir + 'styles'))
    .pipe(connect.reload())
});
gulp.task('watch', function() {
  gulp.watch(jsSources, ['js']);
  gulp.watch(['components/styles/*.css'], ['css']);
  gulp.watch('builds/development/*.html', ['html']);
  //gulp.watch('builds/development/dummy.txt', ['move_files']);
});

gulp.task('html', function() {
  gulp.src('builds/development/*.html')
    .pipe(gulpif(env === 'production', htmlmin({collapseWhitespace: true})))
    .pipe(gulpif(env === 'production', gulp.dest(outputDir)))
    .pipe(connect.reload())
});

// Copy images to production
gulp.task('move', function() {
  gulp.src('builds/development/images/**/*.*')
    .pipe(gulpif(env === 'production', imagemin()))
    .pipe(gulpif(env === 'production', gulp.dest(outputDir+'images')))
});

//Move development files to aarohantest.github.io
// gulp.task('move_files', function() {
//     if(env==='development') {
//       gulp.src('builds/development/*.html')
//         .pipe(gulp.dest('../aarohantest.github.io'))
//
//       gulp.src('builds/development/*.php')
//         .pipe(gulp.dest('../aarohantest.github.io'))
//
//       gulp.src('builds/development/js/*.js')
//         .pipe(gulp.dest('../aarohantest.github.io/js'))
//
//       gulp.src('builds/development/styles/*.css')
//         .pipe(gulp.dest('../aarohantest.github.io/styles'))
//     }
//     else {
//         gulp.src('builds/production/*.html')
//           .pipe(gulp.dest('../aarohantest.github.io'))
//
//         gulp.src('builds/production/*.php')
//           .pipe(gulp.dest('../aarohantest.github.io'))
//
//         gulp.src('builds/production/js/*.js')
//           .pipe(gulp.dest('../aarohantest.github.io/js'))
//
//         gulp.src('builds/production/styles/*.css')
//           .pipe(gulp.dest('../aarohantest.github.io/styles'))
//     }
// });

gulp.task('default', ['watch', 'html', 'js', 'css', 'move', 'connect']);
