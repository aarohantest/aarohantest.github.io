$(document).ready(function () {
    $('#nav-header #header-container #tabs-list li').hover(function(){
        $(this).css({
            "background-color":"#8E5900",
            "cursor":"pointer",
        });
    }, function() {
        $(this).css("background-color","#FFF");
    });
    $('.dropdown').hover(function() {
        $('.dropdown-content').css("transform","translate(-10px,0)");
    }, function() {
        $('.dropdown-content').css("transform","translate(1000%,0)").delay(9000);
    });
});

$(window).load(function () {
    $(".preloader").delay(2000).fadeOut("slow");
});
